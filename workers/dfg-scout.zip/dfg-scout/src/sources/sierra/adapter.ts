// --- SIERRA GRAPHQL QUERIES ---
const GET_AUCTIONS = `query($pagination:AuctionPaginationInput,$filter:AuctionFilterInput,$order:AuctionOrderInput){auctions(pagination:$pagination,filter:$filter,order:$order){auctions{auction_id title end_time}}}`;
const GET_AUCTION_LOTS = `query($auction_id:String!,$pagination:Pagination,$filter:AuctionLotFilterInput){auction(auction_id:$auction_id){lots(pagination:$pagination,filter:$filter){lots{auction_lot_id lot_number title description winning_bid_amount starting_bid primary_image lot_location{city state{abbreviation}}auction_id}}}}`;
const API_BASE = "https://sierraauction.auctioneersoftware.com/api";

export const SierraAdapter = {
  async fetchActiveAuctions(): Promise<any[]> {
    const resp = await fetch(API_BASE, {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({
        query: GET_AUCTIONS,
        variables: {
          pagination: { page: 1, pageSize: 50 },
          filter: { auction_status: [100, 200], is_visible_on_front: true },
          order: { column: "end_time", direction: "asc" }
        }
      })
    });

    if (!resp.ok) throw new Error(`Sierra Auctions Fetch Failed: ${resp.status}`);
    const data: any = await resp.json();
    const now = new Date();
    return (data.data?.auctions?.auctions || []).filter((a: any) => new Date(a.end_time) > now);
  },

  async fetchLots(auctionId: string): Promise<any[]> {
    const all: any[] = [];
    let page = 1;

    while (true) {
      const resp = await fetch(API_BASE, {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          query: GET_AUCTION_LOTS,
          variables: {
            auction_id: auctionId,
            pagination: { page, pageSize: 500 },
            filter: { auction_id: auctionId, is_visible: true }
          }
        })
      });

      if (!resp.ok) throw new Error(`Sierra Lots Fetch Failed: ${resp.status}`);
      const data: any = await resp.json();
      const batch = data.data?.auction?.lots?.lots || [];
      all.push(...batch);
      if (batch.length < 500) break;
      page++;
    }
    return all;
  }
};