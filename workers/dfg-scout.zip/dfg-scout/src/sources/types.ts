export interface RawListing {
  id: string;
  title: string;
  price: number;
  description: string;
  location?: string;
  url: string;
  raw_data: any; // Sierra-specific raw blob for deep analysis
}

export interface Verdict {
  status: 'candidate' | 'rejected';
  categoryId: string | null;
  score: number;
  requiresSnapshot: boolean;
}