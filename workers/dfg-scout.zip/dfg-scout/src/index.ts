import { Env } from './core/env';
import { json, authorize } from './core/http';
import { runScout } from './core/pipeline/runScout';
import { getStats } from './core/pipeline/getStats';

export default {
  async fetch(request: Request, env: Env): Promise<Response> {
    const { pathname } = new URL(request.url);
    const cleanPath = pathname.replace(/\/$/, "");

    // Auth Checks
    const isOps = authorize(request, env, 'ops');
    const isAdmin = authorize(request, env, 'admin');

    // 1. Health Check (Public)
    if (cleanPath === '/health') {
      return json({ status: 'ok', env: env.ENVIRONMENT });
    }

    // 2. Stats Endpoint
    if (cleanPath === '/ops/stats' && (isOps || isAdmin)) {
      try {
        const stats = await getStats(env);
        return json(stats);
      } catch (err: any) {
        return json({ error: 'Stats Failed', details: err.message }, 500);
      }
    }

    // 3. Run Pipeline
    if (cleanPath === '/ops/run' && (isOps || isAdmin)) {
      const results = await runScout(env);
      return json(results);
    }

    // 4. Verify Snapshots
    if (cleanPath === '/ops/verify-snapshots' && isOps) {
      const list = await env.DFG_EVIDENCE.list({ limit: 5 });
      return json({ ok: true, count: list.objects.length, sample: list.objects });
    }

    // Fallback 404 with Debug Info
    return json({ 
      error: 'Not Found', 
      debug: { 
        path: pathname, 
        isOps, 
        isAdmin,
        hasAuthHeader: request.headers.has('Authorization')
      } 
    }, 404);
  }, // This brace closes the fetch function correctly

  async scheduled(event: ScheduledEvent, env: Env, ctx: ExecutionContext) {
    ctx.waitUntil(runScout(env));
  }
};