export interface Verdict {
  status: 'candidate' | 'rejected';
  categoryId: string | null;
  requiresSnapshot: boolean;
  score: number;
}

export class CategoryRouter {
  private categories: any[] = [];
  private env: any;

  // These remain as hardcoded "Nuclear" filters (World-class safety)
  private NEGATIVE_KEYWORDS = [
    "truck", "f-250", "f-350", "f-450", "f-550", "international", "semi", "bus",
    "skid steer", "bobcat", "tractor", "parts only", "scrap", "salvage",
    "mobile home", "rv", "camper", "boat trailer", "no title", "bill of sale"
  ];

  constructor(env: any) {
    this.env = env;
  }

  async load() {
    const results = await this.env.DFG_DB.prepare(
      "SELECT * FROM categories WHERE active = 1"
    ).all();
    this.categories = results.results || [];
  }

  evaluate(lot: any): Verdict {
    const title = (lot.title || "").toLowerCase();
    const description = (lot.description || "").toLowerCase();
    const text = `${title} ${description}`;
    const price = lot.winning_bid_amount || lot.starting_bid || 0;

    // 1. Hard Rejects
    if (price > 6000) return { status: 'rejected', categoryId: null, requiresSnapshot: false, score: 0 };
    if (this.NEGATIVE_KEYWORDS.some(k => text.includes(k))) {
      return { status: 'rejected', categoryId: null, requiresSnapshot: false, score: 0 };
    }

    // 2. Database-Driven Keyword Match
    const match = this.categories.find(cat => {
      const keywords = cat.keywords.split(',').map((k: string) => k.trim().toLowerCase());
      return keywords.some((k: string) => text.includes(k));
    });

    if (!match) return { status: 'rejected', categoryId: null, requiresSnapshot: false, score: 0 };

    // 3. Scoring (Legacy Restored)
    let score = 50;
    if (price <= 1000) score += 25;
    else if (price <= 2000) score += 20;
    else if (price <= 4000) score += 10;
    if (price <= 2000) score += 15;

    return {
      status: 'candidate',
      categoryId: match.id,
      requiresSnapshot: true,
      score: Math.min(score, 100)
    };
  }
}