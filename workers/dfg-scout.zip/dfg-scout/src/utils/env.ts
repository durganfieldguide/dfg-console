import type { Env } from "../index";

export function shouldWriteToCoda(env: Env): boolean {
  return env.ENVIRONMENT !== "preview";
}
