import { Env } from '../env';

export interface OpsStats {
  now: string;
  environment: string;
  inventory: {
    total: number;
    candidates: number;
    rejected: number;
    snapshot_coverage_pct: string;
  };
  health: {
    orphaned_candidates: number;
    last_run_age_minutes: number | null;
  };
}

export async function getStats(env: Env): Promise<OpsStats> {
  const statsQuery = `
    SELECT 
      COUNT(*) AS total,
      SUM(CASE WHEN status = 'candidate' THEN 1 ELSE 0 END) AS candidates,
      SUM(CASE WHEN status = 'rejected' THEN 1 ELSE 0 END) AS rejected,
      SUM(CASE WHEN status = 'candidate' AND (r2_snapshot_key IS NULL OR r2_snapshot_key = '') THEN 1 ELSE 0 END) AS orphaned_candidates,
      SUM(CASE WHEN r2_snapshot_key IS NOT NULL AND r2_snapshot_key != '' THEN 1 ELSE 0 END) AS total_snapshots
    FROM listings;
  `;

  const lastRunQuery = `SELECT created_at FROM scout_runs ORDER BY created_at DESC LIMIT 1;`;

  const metrics: any = await env.DFG_DB.prepare(statsQuery).first();
  const lastRun: any = await env.DFG_DB.prepare(lastRunQuery).first();

  const lastRunTime = lastRun?.created_at ? new Date(lastRun.created_at).getTime() : null;
  const ageMinutes = lastRunTime ? Math.floor((Date.now() - lastRunTime) / 60000) : null;

  return {
    now: new Date().toISOString(),
    environment: env.ENVIRONMENT,
    inventory: {
      total: metrics.total || 0,
      candidates: metrics.candidates || 0,
      rejected: metrics.rejected || 0,
      snapshot_coverage_pct: metrics.candidates > 0 
        ? `${((metrics.total_snapshots / metrics.candidates) * 100).toFixed(1)}%` 
        : '100%'
    },
    health: {
      orphaned_candidates: metrics.orphaned_candidates || 0,
      last_run_age_minutes: ageMinutes
    }
  };
}