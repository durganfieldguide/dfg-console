import { Env, getConfig } from '../env';
import { SierraAdapter } from '../../sources/sierra/adapter';
import { CategoryRouter, Verdict } from '../../categories/router';
import { CodaClient } from "dfg-data-gateway";

export async function runScout(env: Env, options: { dryRun?: boolean } = {}) {
  const config = getConfig(env);
  const startTime = Date.now();
  const startTimeEpoch = Math.floor(startTime / 1000);
  const runId = crypto.randomUUID();
  
  // Track subrequests to stay under Cloudflare's 50-limit
  let subrequestCount = 0;
  const SUBREQUEST_LIMIT = 40; // Leave buffer for Coda and D1 operations

  const router = new CategoryRouter(env);
  await router.load(); 
  subrequestCount++; // D1 Category fetch

  console.log(`[Scout] Starting run ${runId} in ${env.ENVIRONMENT} mode...`);

  const auctions = await SierraAdapter.fetchActiveAuctions();
  subrequestCount++;
  
  const allLots: any[] = [];
  for (const auction of auctions) {
    const lots = await SierraAdapter.fetchLots(auction.auction_id);
    subrequestCount++;
    allLots.push(...lots);
  }

  const existingListings = await env.DFG_DB.prepare(
    `SELECT id, current_bid, r2_snapshot_key FROM listings`
  ).all();
  subrequestCount++;
  
  const stateMap = new Map(existingListings.results?.map(r => [r.id, r]));

  const stats = { total: allLots.length, candidates: 0, snapshots: 0 };
  const d1Statements: any[] = [];
  const candidatesToSync: any[] = [];

  // 4. Process and Evaluate Lots
  for (const raw of allLots) {
    const d1Id = `sierra:${raw.auction_id}:${raw.auction_lot_id}`;
    const price = raw.winning_bid_amount || raw.starting_bid || 0;
    const verdict: Verdict = router.evaluate(raw); 

    const previousState: any = stateMap.get(d1Id);
    const hasPriceChanged = previousState ? previousState.current_bid !== price : true;
    const isNew = !previousState;

    d1Statements.push(env.DFG_DB.prepare(`
        INSERT INTO listings (id, source, source_id, url, title, current_bid, status, category_id, updated_at)
        VALUES (?, 'sierra', ?, ?, ?, ?, ?, ?, ?)
        ON CONFLICT(id) DO UPDATE SET 
          current_bid = excluded.current_bid, 
          status = excluded.status, 
          category_id = excluded.category_id,
          updated_at = excluded.updated_at
      `).bind(
        d1Id, `${raw.auction_id}_${raw.auction_lot_id}`, 
        `https://sierraauction.auctioneersoftware.com/auctions/${raw.auction_id}/lot/${raw.auction_lot_id}`, 
        raw.title, price, verdict.status, verdict.categoryId, startTimeEpoch
      ));

    if (verdict.status === 'candidate') {
      stats.candidates++;

      if (isNew || hasPriceChanged) {
        candidatesToSync.push({ raw, d1Id, price, verdict });
      }

      // Evidence Archiving with Subrequest Budgeting
      if (verdict.requiresSnapshot && !previousState?.r2_snapshot_key && subrequestCount < SUBREQUEST_LIMIT) {
        try {
          const snapshotKey = `snapshots/${d1Id}.json`;
          await env.DFG_EVIDENCE.put(snapshotKey, JSON.stringify(raw));
          subrequestCount++;
          
          const imgUrl = raw.primary_image?.full_url || raw.primary_image?.url;
          if (imgUrl && subrequestCount < SUBREQUEST_LIMIT) {
            const imgResp = await fetch(imgUrl);
            subrequestCount++; 
            if (imgResp.ok) {
              await env.DFG_EVIDENCE.put(`images/${d1Id}.jpg`, await imgResp.arrayBuffer());
              subrequestCount++;
            }
          }

          d1Statements.push(env.DFG_DB.prepare(`UPDATE listings SET r2_snapshot_key = ? WHERE id = ?`)
            .bind(snapshotKey, d1Id));
          stats.snapshots++;
        } catch (e) {
          console.error(`[Scout] Evidence Archiving Error for ${d1Id}:`, e);
        }
      }
    }
  }

  // 5. Execute D1 Batch
  if (d1Statements.length > 0) {
    for (let i = 0; i < d1Statements.length; i += 100) {
      await env.DFG_DB.batch(d1Statements.slice(i, i + 100));
      subrequestCount++;
    }
  }

  // 6. Coda Triple-Table Sync
  if (!options.dryRun && env.CODA_API_TOKEN) {
    try {
      const coda = new CodaClient({ apiToken: env.CODA_API_TOKEN, docId: env.CODA_DOC_ID });
      const [listCols, oppCols, runCols] = await Promise.all([
        coda.getColumnsByName(env.CODA_TABLE_LISTINGS!),
        coda.getColumnsByName(env.CODA_TABLE_OPPORTUNITIES!),
        coda.getColumnsByName(env.CODA_TABLE_RUNS!)
      ]);
      subrequestCount += 3;

      if (candidatesToSync.length > 0) {
        console.log(`[Scout] Syncing ${candidatesToSync.length} candidates. Subrequests used: ${subrequestCount}`);

        const listingRows = candidatesToSync.map(c => {
          const row: any = {};
          const data = { 
            listing_id: c.d1Id, 
            source: "sierra", 
            url: `https://sierraauction.auctioneersoftware.com/auctions/${c.raw.auction_id}/lot/${c.raw.auction_lot_id}`, 
            title: c.raw.title, 
            current_price: c.price, 
            scraped_at: new Date().toISOString() 
          };
          for (const [k, v] of Object.entries(data)) { if (listCols[k]) row[listCols[k]] = v; }
          return row;
        });

        const oppRows = candidatesToSync.map(c => {
          const row: any = {};
          const data = { 
            listing_id: c.d1Id, 
            status: "NEW", 
            priority: c.verdict.score >= 75 ? "HIGH" : "MED", 
            initial_class: c.verdict.score >= 75 ? "STEAL" : "CANDIDATE",
            notes: `Change detected. Score: ${c.verdict.score}`
          };
          for (const [k, v] of Object.entries(data)) { if (oppCols[k]) row[oppCols[k]] = v; }
          return row;
        });

        await coda.upsertRows({ 
          tableId: env.CODA_TABLE_LISTINGS!, 
          keyColumnIds: [listCols["listing_id"] || listCols["id"] || "listing_id"], 
          rowsByColumnId: listingRows 
        });
        subrequestCount++;

        await coda.upsertRows({ 
          tableId: env.CODA_TABLE_OPPORTUNITIES!, 
          keyColumnIds: [oppCols["listing_id"] || oppCols["id"] || "listing_id"], 
          rowsByColumnId: oppRows 
        });
        subrequestCount++;
      }

      // --- Corrected Run Log Block ---
      const runRow: any = {};
      const runData = { 
        run_id: runId, 
        worker: "dfg-scout-v8-modular", 
        started_at: new Date(startTime).toISOString(), 
        ended_at: new Date().toISOString(), 
        counts_json: JSON.stringify(stats) 
      };
      
      // Fix: Corrected variable from 'row' to 'runRow' to resolve "row is not defined"
      for (const [k, v] of Object.entries(runData)) { 
        if (runCols[k]) runRow[runCols[k]] = v; 
      }
      
      await coda.upsertRows({ 
        tableId: env.CODA_TABLE_RUNS!, 
        keyColumnIds: [runCols["run_id"] || runCols["id"] || "run_id"], 
        rowsByColumnId: [runRow] 
      });

      console.log(`[Scout] Coda synchronization successful. Final subrequests: ${subrequestCount}`);
    } catch (err: any) {
      console.error(`[Scout] Coda Sync Error: ${err.message}`);
    }
  }

  return {
    success: true,
    run_id: runId,
    duration: Date.now() - startTime,
    ...stats,
    synced: candidatesToSync.length
  };
}