export const json = (data: any, status = 200) => 
  new Response(JSON.stringify(data), {
    status,
    headers: { 'Content-Type': 'application/json' }
  });

export const authorize = (request: Request, env: Env, type: 'admin' | 'ops') => {
  const authHeader = request.headers.get('Authorization');
  const token = type === 'admin' ? env.RESET_TOKEN : env.OPS_TOKEN;
  
  if (!authHeader || authHeader !== `Bearer ${token}`) {
    return false;
  }
  return true;
};