export interface Env {
  ENVIRONMENT: string;
  MAX_BID_LIMIT: string;
  STEAL_THRESHOLD: string;
  
  // Bindings
  DFG_DB: D1Database;
  DFG_EVIDENCE: R2Bucket;
  SCOUT_KV: KVNamespace;
  ANALYST: Fetcher;

  // Secrets
  RESET_TOKEN: string;
  OPS_TOKEN: string;
  CODA_API_TOKEN: string;
  SIERRA_API_KEY: string;

  // Coda Config
  CODA_DOC_ID: string;
  CODA_TABLE_LISTINGS: string;
  CODA_TABLE_RUNS: string;
}

// The missing export that caused the build error
export const getConfig = (env: Env) => ({
  isProd: env.ENVIRONMENT === 'production',
  isPreview: env.ENVIRONMENT === 'preview',
  maxBid: parseFloat(env.MAX_BID_LIMIT || '6000'),
  stealThreshold: parseFloat(env.STEAL_THRESHOLD || '2000'),
});